# include/ 

Contains a portable aes library that has both C and C++ integrations through NCrypt codebase.
# tcc

The tiny c compiler is perfect for a portable codebase that can operate without major dependencies.

Enjoy the benefits of re-compiling your stub on your own, instead of merely replacing a resource / binary data.
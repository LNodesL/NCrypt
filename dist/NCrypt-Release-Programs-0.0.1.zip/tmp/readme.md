# tmp

This folder is here to temporarily store the encrypted PE file & the associated Stub.h file. Both files are then auto-removed by NCrypt once it's not needed.
# include/ 

This folder contains the Stub header, which is generated on each new crypt to include the file data. It also contains aes/ which is a portable encryption library.

## Stub.h

Do not edit this raw file.

It is auto-replaced when NCrypt.exe is used. If you need to alter the final format, update the code in tools/GenerateHeader.cpp


# tools

This folder contains the SFED & GenerateHeader programs for encrypting the original file & including it in the tmp/Stub.h file.